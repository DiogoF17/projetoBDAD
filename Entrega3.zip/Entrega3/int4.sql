.mode columns
.headers on
.nullvalue NULL

select idfuncionario, entidade.nome, salario
from funcionarioseccao, seccao, entidade
where funcionarioseccao.idseccao = seccao.idseccao and idfuncionario = identidade and seccao.nome like ('Seccao de Soldadura')
ORDER BY entidade.nome ASC;