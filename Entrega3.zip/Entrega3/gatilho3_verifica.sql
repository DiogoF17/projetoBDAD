
.mode columns
.headers on
.nullvalue NULL

PRAGMA foreign_keys = ON;

select * from materiaprima;

insert into produtomateriaprima values(1, 1, 700);


select * from materiaprima;

insert into produtomateriaprima values(1, 9, 199);

select * from materiaprima;