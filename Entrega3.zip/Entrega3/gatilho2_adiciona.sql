.mode columns
.headers on
.nullvalue NULL

PRAGMA foreign_keys = ON;

create trigger cantWorkMore
before insert on FuncionarioSeccao
begin
	select case
	when((select count(*) 
	from FuncionarioSeccao
	group by idFuncionario) > 2)
	then raise(abort, 'Um funcionario nao pode trabalhar em mais que 3 seccoes!')
end;
end;