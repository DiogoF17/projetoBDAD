.mode columns
.headers on
.nullvalue NULL

PRAGMA foreign_keys = ON;

//verifica o primeiro trigger
select * from compra;
select * from produtocompra;

insert into compra values(11, '2020-05-22', 2);
insert into produtocompra values(1, 11, 600);

select * from compra;
select * from produtocompra;

//verifica o segundo trigger
select * from produtocompra;

insert into produtocompra values(2, 11, 100);

select * from produtocompra;