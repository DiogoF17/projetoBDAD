.mode columns
.headers on
.nullvalue NULL

select max(custoprod) as MaxPreco, min(custoprod) as MinPreco, avg(custoprod) as AVGPreco
from produto;