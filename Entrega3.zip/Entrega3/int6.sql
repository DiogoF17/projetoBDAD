.mode columns
.headers on
.nullvalue NULL

select idmateriaprima,designacao,sum(quantidade) as quantUtilizada 
from (produtoMateriaPrima natural join materiaprima) 
group by idmateriaprima 
order by quantUtilizada 
desc limit 5;