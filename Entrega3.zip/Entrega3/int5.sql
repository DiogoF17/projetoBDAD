.mode columns
.headers on
.nullvalue NULL

select produtocompra.idproduto, designacao
from produtocompra, produto, (select idcompra, max(valor)
from fatura) p
where produtocompra.idcompra = p.idcompra and produtocompra.idproduto = produto.idproduto;