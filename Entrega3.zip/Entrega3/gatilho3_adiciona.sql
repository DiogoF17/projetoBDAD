.mode columns
.headers on
.nullvalue NULL

PRAGMA foreign_keys = ON;

create trigger updateStockMateriaPrima
after insert on ProdutoMateriaPrima
begin
	update MateriaPrima set quantDisp = quantDisp - new.quantidade where(MateriaPrima.idMateriaPrima = new.idMateriaPrima);
end;

create trigger increaseStockMateriaPrima
after update on MateriaPrima
when(new.quantDisp <= 50)
begin
	update MateriaPrima set quantDisp = new.quantDisp + 500 where(MateriaPrima.idMateriaPrima = new.idMateriaPrima);
end;