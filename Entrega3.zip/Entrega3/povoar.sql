PRAGMA encoding="UTF-8";
PRAGMA foreign_keys=true;

insert into Entidade values(1, 'King 2000 Ferragens Forjadas, Lda', 231423564, 'Rua Principal n566, Lobao', '4505-422', 256778901);
insert into Entidade values(4, 'Securitas Direct', 231923564, 'Via Futebol Clube do Porto', '4350-422', 916612521);
insert into Entidade values(5, 'Pro Higiene', 231423514, 'Rua das Camelias, Santarem', '4705-422', 256778901);
insert into Entidade values(2, 'Resende e Tavares, Lda', 231423565, 'Rua Quinta de Cima n340, Vale', '4525-422', 256078902);
insert into Entidade values(14, 'Augusto Pacheco e Sa', 551423565, 'Rua de Portugal, Alentejo', '4596-424', 256878990);
insert into Entidade values(15, 'Miragaia Ferragens', 777423565, 'Rua das Freiras n220, Gaia', '4525-4506', 256028902);
insert into Entidade values(16, 'Fontao Ferragens', 231223565, 'Travessa do Luar, Portalegre', '1025-422', 256078920);
insert into Entidade values(17, 'Vitorex Ferramentas', 231783565, 'Via Antonio Machado, Porto', '4350-422', 256033902);
insert into Entidade values(18, 'Sady Ferragens', 231429965, 'Rua do Conhecimento, Gaia', '4525-506', 256125902);
insert into Entidade values(19, 'Manuel Dias', 233333565, 'Rua Camoes, Santa Maria da Feira', '4895-412', 256333902);
insert into Entidade values(3, 'Fernando de Oliveira Bernardes', 221423564, 'Rua Quinta de Cima n339, Vale', '4525-422', 256008903);
insert into Entidade values(6, 'Alberto da Silva Azevedo', 221423560, 'Rua dos Capuchos n20, Vila Maior', '2001-402', 256008904);
insert into Entidade values(7, 'Manuel Pereira Pinto', 221423561, 'Rua Carlos e Silv, Canedo', '2001-552', 256008951);
insert into Entidade values(8, 'Adelaide Gomes Sa', 221423562, 'Rua dos Pirilampos, Fiaes', '4025-322', 256118905);
insert into Entidade values(9, 'Adao da Silva Pinto', 221423563, 'Rua da Guerra, Canedo', '2001-552', 256008961);
insert into Entidade values(10, 'Felizmina Joao Oliveira Jesus', 221423565, 'Rua da Travessa Escondida, Castelo de Paiva', '4621-333', 256008906);
insert into Entidade values(11, 'Pedro da Silva Pinto', 221423566, 'Rua do Cafe, Caldas de Sao Jorge', '4000-422', 256798901);
insert into Entidade values(12, 'Artur Escoval Pereira', 221423567, 'Rua dos Saltitoes n80, Sao Joao de Ver', '4520-429', 256008901);
insert into Entidade values(13, 'Timoteo Filipe Guedes Sousa', 221423568, 'Rua dos Canteiros, Rio Meao', '4727-472', 252008901);
insert into Entidade values(20, 'Tinto Pais', 491423568, 'Rua da Granja, Castelo de Paiva', '4621-333', 252074901);
insert into Entidade values(21, 'Leonel Pinto', 223423568, 'Rua da Ignorancia, Viana do Castelo', '4720-472', 252632901);
insert into Entidade values(22, 'Chapas Resende', 200003568, 'Rua Luis de Camoes, Lisboa', '4000-472', 252025901);
insert into Entidade values(23, 'Tintas e Vernizes Pinto', 221421111, 'Rua da Luz, Sao Joao da Madeira', '4555-455', 251515154);
insert into Entidade values(24, 'Manuel Pinto Chapas, Acos e outros Componentes', 224444568, 'Rua do Ameal, Sao Pedro do Sul', '4888-488', 252888888);
insert into Entidade values(25, 'Acail Gas', 224444149, 'Rua da Travada, Travanca', '4843-001', 252111118);
insert into Entidade values(26, 'Diogo Santos Tudo para Seguranca', 224444000, 'Rua das Alminhas, Paradela', '4525-409', 917008888);

insert into Empresa values(1, '2000-02-05', 23142564);
insert into Empresa values(4, '2005-08-23', 22356400);
insert into Empresa values(5, '1998-09-09', 001423514);

insert into Banco values(1, '234', 'Millenium');
insert into Banco values(2, '598', 'Caixa Geral de Depositos');
insert into Banco values(3, '001', 'Santander Totta');
insert into Banco values(4, '510', 'Credito Agricola');
insert into Banco values(5, '963', 'BPI');
insert into Banco values(6, '500', 'Montepio');

insert into Funcionario values(3, 24, '1973-11-02', '2010-07-06', 55554555, 11111120, 'Frezador', 1, 1);
insert into Funcionario values(6, 5,'1985-01-05', '2000-12-06', 55504555, 11111121, 'Soldador', 2, 1);
insert into Funcionario values(7, 15,'1990-03-09', '2005-02-21', 55554551, 11111122, 'Polidor', 3, 1);
insert into Funcionario values(8, 1,'1978-01-05', '2009-04-29', 55554553, 11111123, 'Marketing', 4, 1);
insert into Funcionario values(9, 9,'2000-08-29', '2012-09-10', 55554500, 11111124, 'Pintor', 5, 1);
insert into Funcionario values(10, 23,'1980-10-09', '2019-04-30', 55554789, 11111155, 'Contabilista', 6, 1);
insert into Funcionario values(11, 6,'1993-10-23', '1999-07-06', 555545741, 11111190, 'Torneiro', 6, 1);
insert into Funcionario values(12, 4,'1987-06-14', '2007-01-16', 55551230, 11112222, 'Temperador', 5, 1);
insert into Funcionario values(13, 19,'1992-07-27', '2011-08-26', 55554510, 11511120, 'Embalador', 1, 1);

insert into Cliente values(2, 5, 'empresa', 'Portugal', 'fora de cobrancas');
insert into Cliente values(14, 6, 'particular', 'Portugal', 'fora de cobrancas');
insert into Cliente values(15, 7, 'empresa', 'Portugal', 'fora de cobrancas');
insert into Cliente values(16, 8, 'empresa', 'Portugal', 'cobrancas');
insert into Cliente values(17, 9, 'empresa', 'Portugal', 'contencioso');
insert into Cliente values(18, 10, 'empresa', 'Portugal', 'cobrancas');
insert into Cliente values(19, 11, 'particular', 'Portugal', 'fora de cobrancas');

insert into Fornecedor values(20, 1);
insert into Fornecedor values(21, 2);
insert into Fornecedor values(22, 3);
insert into Fornecedor values(23, 4);
insert into Fornecedor values(24, 5);
insert into Fornecedor values(25, 6);
insert into Fornecedor values(26, 7);

insert into Contrato values(1, '2010-09-18', 400, 1, 4);
insert into Contrato values(2, '2015-10-20', 100, 1, 5);

insert into EmpresaCliente values(1, 2);
insert into EmpresaCliente values(1, 19);
insert into EmpresaCliente values(1, 15);
insert into EmpresaCliente values(1, 14);
insert into EmpresaCliente values(1, 16);
insert into EmpresaCliente values(1, 18);
insert into EmpresaCliente values(1, 17);

insert into EmpresaFornecedor values(1,20);
insert into EmpresaFornecedor values(1,21);
insert into EmpresaFornecedor values(1,22);
insert into EmpresaFornecedor values(1,23);
insert into EmpresaFornecedor values(1,24);

insert into Seccao values(1, 'Seccao de Polimento', 1);
insert into Seccao values(2, 'Seccao de Frezar', 1);
insert into Seccao values(3, 'Seccao de Soldadura', 1);
insert into Seccao values(4, 'Seccao de Embalamento', 1);
insert into Seccao values(5, 'Seccao de Tornos', 1);
insert into Seccao values(6, 'Seccao de Pintura', 1);
insert into Seccao values(7, 'Seccao de Tempera', 1);
insert into Seccao values(8, 'Seccao de Markting', 1);
insert into Seccao values(9, 'Seccao de Contabilidade', 1);

insert into FuncionarioSeccao values(3, 1, 700.000);
insert into FuncionarioSeccao values(6, 2, 750.000);
insert into FuncionarioSeccao values(7, 3, 780.000);
insert into FuncionarioSeccao values(8, 8, 900.000);
insert into FuncionarioSeccao values(9, 9, 900.000);
insert into FuncionarioSeccao values(10, 4, 650.000);
insert into FuncionarioSeccao values(11, 5, 770.000);
insert into FuncionarioSeccao values(12, 6, 720.000);
insert into FuncionarioSeccao values(13, 7, 690.000);

insert into Administrativa values(8, 'Marketing');
insert into Administrativa values(9, 'Contabilidade');

insert into Producao values(1);
insert into Producao values(2);
insert into Producao values(3);
insert into Producao values(4);
insert into Producao values(5);
insert into Producao values(6);
insert into Producao values(7);

insert into Produto values(1, 'Enxada de Mato Red N3', 3, 500);
insert into Produto values(2, 'Enxada Ponta Faca N1', 2.5, 600);
insert into Produto values(3, 'Enxada Ponta Faca N2', 2.6, 600);
insert into Produto values(4, 'Enxada Ponta Faca N3', 2.7, 600);
insert into Produto values(5, 'Enxada Nacional N000', 1.8, 1000);
insert into Produto values(6, 'Sacho Monda Bico GR', 1, 1500);
insert into Produto values(7, 'Sacho com Cabo Bico', 1.2, 1500);
insert into Produto values(8, 'Catana King 16', 4, 2000);
insert into Produto values(9, 'Raspador Leiria 300x150', 2, 150);
insert into Produto values(10, 'Machadinha Poda', 1.1, 5000);
insert into Produto values(11, 'Talhadeira', 1.5, 2000);
insert into Produto values(12, 'Ancinho de Batatas 5 Dentes', 1, 300);
insert into Produto values(13, 'Pá Francesa com Cabo de Madeira', 3, 5000);

insert into ProducaoProduto values(6, 1);
insert into ProducaoProduto values(6, 2);
insert into ProducaoProduto values(6, 3);
insert into ProducaoProduto values(6, 4);
insert into ProducaoProduto values(6, 5);
insert into ProducaoProduto values(6, 6);
insert into ProducaoProduto values(6, 7);
insert into ProducaoProduto values(7, 1);
insert into ProducaoProduto values(7, 2);
insert into ProducaoProduto values(7, 3);
insert into ProducaoProduto values(7, 4);
insert into ProducaoProduto values(7, 5);
insert into ProducaoProduto values(7, 6);
insert into ProducaoProduto values(7, 7);
insert into ProducaoProduto values(8, 1);
insert into ProducaoProduto values(8, 2);
insert into ProducaoProduto values(8, 3);
insert into ProducaoProduto values(8, 4);
insert into ProducaoProduto values(8, 5);
insert into ProducaoProduto values(8, 6);
insert into ProducaoProduto values(8, 7);
insert into ProducaoProduto values(9, 1);
insert into ProducaoProduto values(9, 2);
insert into ProducaoProduto values(9, 3);
insert into ProducaoProduto values(9, 4);
insert into ProducaoProduto values(9, 5);
insert into ProducaoProduto values(9, 6);
insert into ProducaoProduto values(9, 7);

insert into ProdutoFuncionario values(1, 3);
insert into ProdutoFuncionario values(1, 6);
insert into ProdutoFuncionario values(1, 7);
insert into ProdutoFuncionario values(1, 9);
insert into ProdutoFuncionario values(1, 11);
insert into ProdutoFuncionario values(1, 12);
insert into ProdutoFuncionario values(1, 13);
insert into ProdutoFuncionario values(2, 3);
insert into ProdutoFuncionario values(2, 6);
insert into ProdutoFuncionario values(2, 7);
insert into ProdutoFuncionario values(2, 9);
insert into ProdutoFuncionario values(2, 11);
insert into ProdutoFuncionario values(2, 12);
insert into ProdutoFuncionario values(2, 13);
insert into ProdutoFuncionario values(3, 3);
insert into ProdutoFuncionario values(3, 6);
insert into ProdutoFuncionario values(3, 7);
insert into ProdutoFuncionario values(3, 9);
insert into ProdutoFuncionario values(3, 11);
insert into ProdutoFuncionario values(3, 12);
insert into ProdutoFuncionario values(3, 13);
insert into ProdutoFuncionario values(4, 3);
insert into ProdutoFuncionario values(4, 6);
insert into ProdutoFuncionario values(4, 7);
insert into ProdutoFuncionario values(4, 9);
insert into ProdutoFuncionario values(4, 11);
insert into ProdutoFuncionario values(4, 12);
insert into ProdutoFuncionario values(4, 13);
insert into ProdutoFuncionario values(5, 3);
insert into ProdutoFuncionario values(5, 6);
insert into ProdutoFuncionario values(5, 7);
insert into ProdutoFuncionario values(5, 9);
insert into ProdutoFuncionario values(5, 11);
insert into ProdutoFuncionario values(5, 12);
insert into ProdutoFuncionario values(5, 13);

insert into Compra values(1,'2011-09-29',14);
insert into Compra values(2,'2011-03-12',2);
insert into Compra values(3,'2010-12-01',18);
insert into Compra values(4,'2015-06-13',19);
insert into Compra values(5,'2016-01-28',2);
insert into Compra values(6,'2010-05-20',15);
insert into Compra values(7,'2015-08-19',16);
insert into Compra values(8,'2014-05-17',17);
insert into Compra values(9,'2014-04-09',18);

insert into ProdutoCompra values(8,1,1);
insert into ProdutoCompra values(1,1,2);
insert into ProdutoCompra values(12,1,3);
insert into ProdutoCompra values(13,1,1);
insert into ProdutoCompra values(5,2,100);
insert into ProdutoCompra values(12,4,3);
insert into ProdutoCompra values(12,9,50);
insert into ProdutoCompra values(3,8,110);
insert into ProdutoCompra values(9,6,60);
insert into ProdutoCompra values(4,3,10);
insert into ProdutoCompra values(11,5,28);
insert into ProdutoCompra values(6,7,30);

insert into Fatura values(1,13.53,0.23,1);
insert into Fatura values(2,221.4,0.23,2);
insert into Fatura values(3,33.21,0.23,3);
insert into Fatura values(4,3.69,0.23,4);
insert into Fatura values(5,51.66,0.23,5);
insert into Fatura values(6,147.6,0.23,6);
insert into Fatura values(7,36.9,0.23,7);
insert into Fatura values(8,351.78,0.23,8);
insert into Fatura values(9,61.5,0.23,9);

insert into MateriaPrima values(1,'Aco Inox',900);
insert into MateriaPrima values(2,'Latao',750);
insert into MateriaPrima values(3,'Verga Estribada',1000);
insert into MateriaPrima values(4,'Madeira',1000);
insert into MateriaPrima values(5,'Tubo Galbanizado e Ferro',1000);
insert into MateriaPrima values(6, 'Gas de Soldadura e Tempera', 50);
insert into MateriaPrima values(7, 'Fio de Solda', 50);
insert into MateriaPrima values(8, 'Tintas', 1000);
insert into MateriaPrima values(9, 'Oculos', 50);
insert into MateriaPrima values(10, 'Vernizes', 1000);
insert into MateriaPrima values(11, 'Luvas', 50);
insert into MateriaPrima values(12, 'Viseiras', 50);
insert into MateriaPrima values(13, 'Aventais de Couro', 50);
insert into MateriaPrima values(14, 'Botas', 50);
insert into MateriaPrima values(15, 'Chapa de Aco', 100);

insert into ProdutoMateriaPrima values(5, 1, 0.005);
insert into ProdutoMateriaPrima values(15, 2, 0.150);
insert into ProdutoMateriaPrima values(5, 2, 0.005);
insert into ProdutoMateriaPrima values(15, 3, 0.200);
insert into ProdutoMateriaPrima values(5, 3, 0.005);
insert into ProdutoMateriaPrima values(15, 4, 0.250);
insert into ProdutoMateriaPrima values(5, 4, 0.005);
insert into ProdutoMateriaPrima values(15, 5, 0.050);
insert into ProdutoMateriaPrima values(5, 5, 0.005);
insert into ProdutoMateriaPrima values(15, 6, 0.025);
insert into ProdutoMateriaPrima values(5, 6, 0.05);
insert into ProdutoMateriaPrima values(15, 7, 0.030);
insert into ProdutoMateriaPrima values(5, 7, 0.05);
insert into ProdutoMateriaPrima values(4, 7, 0.02);
insert into ProdutoMateriaPrima values(15, 8, 0.300);
insert into ProdutoMateriaPrima values(4, 8, 0.025);
insert into ProdutoMateriaPrima values(15, 9, 0.200);
insert into ProdutoMateriaPrima values(5, 9, 0.400);
insert into ProdutoMateriaPrima values(3, 10, 0.200);
insert into ProdutoMateriaPrima values(4, 10, 0.150);
insert into ProdutoMateriaPrima values(3, 11, 0.300);
insert into ProdutoMateriaPrima values(15, 12, 0.400);
insert into ProdutoMateriaPrima values(15, 13, 0.350);
insert into ProdutoMateriaPrima values(4, 11, 0.400);

insert into FornecedorMateriaPrima values(24,2,7.9);
insert into FornecedorMateriaPrima values(21,1,3.9);
insert into FornecedorMateriaPrima values(22,3,5.9);
insert into FornecedorMateriaPrima values(20,4,6.0);
insert into FornecedorMateriaPrima values(21,4,6.0);
insert into FornecedorMateriaPrima values(24, 5, 1.0);
insert into FornecedorMateriaPrima values(23, 8, 6.0);
insert into FornecedorMateriaPrima values(23, 10, 5.0);
insert into FornecedorMateriaPrima values(26, 9, 2.0);
insert into FornecedorMateriaPrima values(26, 11, 1.0);
insert into FornecedorMateriaPrima values(26, 12, 3.0);
insert into FornecedorMateriaPrima values(26, 13, 4.0);
insert into FornecedorMateriaPrima values(26, 14, 20.0);
insert into FornecedorMateriaPrima values(22, 15, 600);






