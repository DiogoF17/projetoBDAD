.mode columns
.headers on
.nullvalue NULL

select materiaprima.designacao
from materiaprima, (select idmateriaprima
from produtomateriaprima, (select idproduto
from produto
where designacao like ('Pá Francesa com Cabo de Madeira')) p
where produtomateriaprima.idproduto = p.idproduto and idmateriaprima not in (
select idmateriaprima
from produtomateriaprima, (select idproduto
from produto
where designacao like ('Talhadeira')) p
where produtomateriaprima.idproduto = p.idproduto))p1
where p1.idmateriaprima = materiaprima.idmateriaprima;