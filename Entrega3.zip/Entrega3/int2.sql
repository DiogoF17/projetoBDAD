.mode columns
.headers on
.nullvalue NULL

select * 
from materiaprima 
where quantDisp <= 100;