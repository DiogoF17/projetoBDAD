.mode columns
.headers on
.nullvalue NULL

select designacao
from produto;