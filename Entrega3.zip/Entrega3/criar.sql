PRAGMA encoding="UTF-8";
PRAGMA foreign_keys=true;

DROP TABLE IF EXISTS ProdutoMateriaPrima;
DROP TABLE IF EXISTS FornecedorMateriaPrima;
DROP TABLE IF EXISTS Fatura;
DROP TABLE IF EXISTS MateriaPrima;
DROP TABLE IF EXISTS ProdutoCompra;
DROP TABLE IF EXISTS Compra;
DROP TABLE IF EXISTS ProdutoFuncionario;
DROP TABLE IF EXISTS ProducaoProduto;
DROP TABLE IF EXISTS Administrativa;
DROP TABLE IF EXISTS Producao;
DROP TABLE IF EXISTS FuncionarioSeccao;
DROP TABLE IF EXISTS EmpresaFornecedor;
DROP TABLE IF EXISTS Seccao;
DROP TABLE IF EXISTS EmpresaCliente;
DROP TABLE IF EXISTS Contrato;
DROP TABLE IF EXISTS Funcionario;
DROP TABLE IF EXISTS Fornecedor;
DROP TABLE IF EXISTS Cliente;
DROP TABLE IF EXISTS Empresa;
DROP TABLE IF EXISTS Entidade;
DROP TABLE IF EXISTS Banco;
DROP TABLE IF EXISTS Produto;

CREATE TABLE Entidade
(   idEntidade INTEGER,
    nome VARCHAR(100) NOT NULL, /*acho que podemos tirar o not null chegamos la com o id*/
    nif CHAR(9) NOT NULL UNIQUE,
    morada VARCHAR(100) NOT NULL,
    codPostal VARCHAR(8) NOT NULL,
    telefone VARCHAR(15) NOT NULL,
    CONSTRAINT entidade_pk PRIMARY KEY (idEntidade)
);

CREATE TABLE Empresa
(   idEntidade INTEGER REFERENCES Entidade(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    dataFormacao DATA NOT NULL,
    niss VARCHAR(11) NOT NULL UNIQUE,
    CONSTRAINT empresa_pk PRIMARY KEY (idEntidade)
);

CREATE TABLE Banco
(   idBanco INTEGER,
    codBanco CHAR(4) NOT NULL UNIQUE,
    nome VARCHAR(100) NOT NULL UNIQUE,
    CONSTRAINT banco_pk PRIMARY KEY (idBanco)
);

CREATE TABLE Funcionario
(   idEntidade INTEGER REFERENCES Entidade(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    idFuncionario INTEGER NOT NULL UNIQUE,
    dataNascimento DATE NOT NULL,
    dataAdmissao DATE NOT NULL,
    niss VARCHAR(11) NOT NULL UNIQUE,
    iban VARCHAR(34) NOT NULL UNIQUE,
    especialidade VARCHAR(100) NOT NULL,
    idBanco INTEGER REFERENCES Banco(idBanco) ON DELETE SET NULL ON UPDATE CASCADE,
    idEmpresa INTEGER REFERENCES Empresa(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    CHECK(dataAdmissao > dataNascimento),
    CONSTRAINT funcionario_pk PRIMARY KEY (idEntidade)
);

CREATE TABLE Cliente
(   idEntidade INTEGER REFERENCES Entidade(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    idCliente INTEGER NOT NULL UNIQUE,
    tipo VARCHAR(10) CHECK(tipo = 'particular' OR tipo = 'empresa') NOT NULL,
    pais VARCHAR(30),
    estado VARCHAR(17) CHECK(estado = 'fora de cobrancas' OR estado = 'cobrancas' OR estado = 'contencioso') NOT NULL,
    CONSTRAINT cliente_pk PRIMARY KEY (idEntidade)
);

CREATE TABLE Fornecedor
(   idEntidade INTEGER REFERENCES Entidade(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    idFornecedor INTEGER NOT NULL UNIQUE,
    CONSTRAINT fornecedor_pk PRIMARY KEY (idEntidade)
);

CREATE TABLE Contrato
(   idContrato INTEGER,
    dataContrato DATA NOT NULL,
    valorMensal DECIMAL(10,3) CHECK(valorMensal>0) NOT NULL,
    idEmpresa1 INTEGER REFERENCES Empresa(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    idEmpresa2 INTEGER REFERENCES Empresa(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT contrato_pk PRIMARY KEY (idContrato)
);

CREATE TABLE EmpresaCliente
(   idEmpresa INTEGER REFERENCES Empresa(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    idCliente INTEGER REFERENCES Cliente(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT empresacliente_pk PRIMARY KEY (idEmpresa,idCliente)
);

CREATE TABLE EmpresaFornecedor
(   idEmpresa INTEGER REFERENCES Empresa(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    idFornecedor INTEGER REFERENCES Fornecedor(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT empresafornecedor_pk PRIMARY KEY (idEmpresa,idFornecedor)
);

CREATE TABLE Seccao
(   idSeccao INTEGER,
    nome VARCHAR(100) NOT NULL,
    idEmpresa INTEGER REFERENCES Empresa(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT seccao_pk PRIMARY KEY (idSeccao)
);

CREATE TABLE FuncionarioSeccao
(   idFuncionario INTEGER REFERENCES Funcionario(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    idSeccao INTEGER REFERENCES Seccao(idSeccao) ON DELETE SET NULL ON UPDATE CASCADE,
    salario DECIMAL(10,3) CHECK(salario>0) NOT NULL,
    CONSTRAINT funcionarioseccao_pk PRIMARY KEY (idFuncionario,idSeccao)
);

CREATE TABLE Administrativa
(   idSeccao INTEGER REFERENCES Seccao(idSeccao) ON DELETE SET NULL ON UPDATE CASCADE,
    departamento VARCHAR(100) NOT NULL,
    CONSTRAINT administrativaseccao_pk PRIMARY KEY (idSeccao)
);

CREATE TABLE Producao
(   idSeccao INTEGER REFERENCES Seccao(idSeccao) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT producao_pk PRIMARY KEY (idSeccao)
);

CREATE TABLE Produto
(   idProduto INTEGER,
    designacao VARCHAR(100) NOT NULL UNIQUE,
    custoProd FLOAT CHECK(custoProd>0) NOT NULL,
    quantDisp INTEGER CHECK(quantDisp>=0) NOT NULL,
    CONSTRAINT produto_pk PRIMARY KEY (idProduto)
);

CREATE TABLE ProducaoProduto
(   idProduto INTEGER REFERENCES Produto(idProduto),
    idProducao INTEGER REFERENCES Producao(idSeccao),
    CONSTRAINT producaoproduto_pk PRIMARY KEY (idProduto, idProducao)
);

CREATE TABLE ProdutoFuncionario
(   idProduto INTEGER REFERENCES Produto(idProduto) ON DELETE SET NULL ON UPDATE CASCADE,
    idFuncionario INTEGER REFERENCES Funcionario(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT produtofuncionario_pk PRIMARY KEY (idProduto,idFuncionario)
);

CREATE TABLE Compra
(   idCompra INTEGER,
    dataDeCompra DATA NOT NULL,
    idCliente INTEGER REFERENCES Cliente(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT compra_pk PRIMARY KEY (idCompra)
);

CREATE TABLE ProdutoCompra
(   idProduto INTEGER REFERENCES Produto(idProduto) ON DELETE SET NULL ON UPDATE CASCADE,
    idCompra INTEGER REFERENCES Compra(idCompra) ON DELETE SET NULL ON UPDATE CASCADE,
    quantidade INTEGER CHECK(quantidade>0) NOT NULL,
    CONSTRAINT produtocompra_pk PRIMARY KEY (idProduto,idCompra)
);

CREATE TABLE Fatura
(   idFatura INTEGER,
    valor DECIMAL(10,3) CHECK(valor > 0) NOT NULL,
    iva FLOAT,
    idCompra INTEGER UNIQUE REFERENCES Compra(idCompra) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fatura_pk PRIMARY KEY (idFatura)
);

CREATE TABLE MateriaPrima
(   idMateriaPrima INTEGER,
    designacao VARCHAR(100) NOT NULL UNIQUE,
    quantDisp INTEGER CHECK(quantDisp>=0) NOT NULL,
    CONSTRAINT materiaprima_pk PRIMARY KEY (idMateriaPrima)
);

CREATE TABLE ProdutoMateriaPrima
(   idMateriaPrima INTEGER REFERENCES MateriaPrima(idMateriaPrima) ON DELETE SET NULL ON UPDATE CASCADE,
    idProduto INTEGER REFERENCES Produto(idProduto) ON DELETE SET NULL ON UPDATE CASCADE,
    quantidade FLOAT CHECK(quantidade>=0) NOT NULL,
    CONSTRAINT produtomateriaprima_pk PRIMARY KEY (idMateriaPrima,idProduto)
);

CREATE TABLE FornecedorMateriaPrima
(   idFornecedor INTEGER REFERENCES Fornecedor(idEntidade) ON DELETE SET NULL ON UPDATE CASCADE,
    idMateriaPrima INTEGER REFERENCES MateriaPrima(idMateriaPrima) ON DELETE SET NULL ON UPDATE CASCADE,
    preco DECIMAL(10,3) CHECK(preco > 0) NOT NULL,
    CONSTRAINT fornecedormateriaprima_pk PRIMARY KEY (idFornecedor,idMateriaPrima)
);


