.mode columns
.headers on
.nullvalue NULL

PRAGMA foreign_keys = ON;

create trigger updateStockProduto
after insert on ProdutoCompra
begin
	update Produto set quantDisp = quantDisp - new.quantidade where (Produto.idProduto = new.idProduto);
end;