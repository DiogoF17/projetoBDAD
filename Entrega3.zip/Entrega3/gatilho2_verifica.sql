.mode columns
.headers on
.nullvalue NULL

PRAGMA foreign_keys = ON;

select * from funcionarioseccao;

insert into funcionarioseccao values(3, 2, 800);

select * from funcionarioseccao;

insert into funcionarioseccao values(3, 3, 800);

select * from funcionarioseccao;

insert into funcionarioseccao values(3, 4, 800);



