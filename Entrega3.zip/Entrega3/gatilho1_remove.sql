.mode columns
.headers on
.nullvalue NULL

PRAGMA foreign_keys = ON;

drop trigger if exists updateStockProduto;