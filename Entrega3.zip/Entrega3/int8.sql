.mode columns
.headers on
.nullvalue NULL

drop VIEW if exists Despesas;
drop VIEW if exists Ganhos;

create view Despesas as select designacao,sum(quantDisp*preco) as despesas from (fornecedormateriaprima natural join materiaprima) group by designacao;
create view Ganhos as select designacao,sum(quantidade*custoprod) as ganhos from (produtocompra natural join produto) group by designacao;
select (g-d) as BalancoDaEmpresa from (select sum(ganhos) as g from ganhos),(select sum(despesas) as d from despesas);
