.mode columns
.headers on
.nullvalue NULL

select entidade.nome
from entidade, funcionario
where entidade.identidade = funcionario.identidade and funcionario.identidade not in (
select idfuncionario
from funcionarioseccao, (select idproducao
from producaoproduto, (select idproduto, min(custoprod)
from produto) p
where p.idproduto = producaoproduto.idproduto) p1
where p1.idproducao = funcionarioseccao.idseccao);