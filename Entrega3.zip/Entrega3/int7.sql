.mode columns
.headers on
.nullvalue NULL

select entidade.nome, estado,  idFatura, valor, Cast ((JulianDay(DATE( )) - JulianDay(dataDeCompra)
) As Integer) as DiasVencidos
from cliente, entidade, fatura, compra
where cliente.identidade = entidade.identidade and cliente.estado != "fora de cobrancas" AND fatura.idcompra = compra.idcompra and compra.idcliente = entidade.identidade;